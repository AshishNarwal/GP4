package com.ashish.dao;

public interface VendorDAO {
	
	public boolean authVendor(int vendroId,String passowrd);
	public int getStatus(int vendorId);

}
