package com.ashish.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.ashish.helper.ConnectionManager;

public class JDBCVendorDAOImpl implements VendorDAO{
 
	ConnectionManager manager=new ConnectionManager();
	
	
	public boolean authVendor(int vendorId, String password) {
		// TODO Auto-generated method stub
		boolean result=false;
		Connection connection=manager.openConnection();
		PreparedStatement statement;
		try {
			statement = connection.prepareStatement("select * from VENDORDATA where VENDOR_ID=? and PASSWORD=?");
			statement.setInt(1,vendorId);
			statement.setString(2,password);
			ResultSet resultSet=statement.executeQuery();
			while(resultSet.next())
			{
		    result=true;
			}
		    
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("SQL Exception caught");
			e.printStackTrace();
		}
		
		return result;
	}

	@Override
	public int getStatus(int vendorId) {
		// TODO Auto-generated method stub
		int result=0;
		Connection connection=manager.openConnection();
		PreparedStatement statement;
		try {
			statement = connection.prepareStatement("select * from USERDATA1 where VENDOR_ID=?");
			statement.setInt(1,vendorId);
			ResultSet resultSet=statement.executeQuery();
			while(resultSet.next())
			{
		    result=resultSet.getInt("STATUS");
			}
		    System.out.println("Status :"+result);
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("SQL Exception caught");
			e.printStackTrace();
		}
		
		return result;
	}
	
	

}
