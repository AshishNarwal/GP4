package com.ashish.helper;

import com.ashish.dao.VendorDAO;

import com.ashish.dao.JDBCVendorDAOImpl;

public class FactoryVendorDAO {

	
	public static VendorDAO createVendorDAO() {
		// TODO Auto-generated method stub
		VendorDAO adminDAO=new JDBCVendorDAOImpl();
		return adminDAO;
	}
}
