package com.ashish.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ashish.dao.VendorDAO;
import com.ashish.helper.FactoryVendorDAO;

/**
 * Servlet implementation class VendorLoginClass
 */
@WebServlet(name = "VendorLogin", urlPatterns = { "/vendorlogin" })
public class VendorLoginClass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public VendorLoginClass() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int count=3;
		int vendorId=Integer.parseInt(request.getParameter("username"));
		String password=request.getParameter("password");
		VendorDAO vendorDAO=FactoryVendorDAO.createVendorDAO();
		boolean result=vendorDAO.authVendor(vendorId,password);
		int status=vendorDAO.getStatus(vendorId);
		if(result && status==1)
		{
			
		}
		else
		{
			
		}
	}

}
