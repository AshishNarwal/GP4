package com.cognizant.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cognizant.entity.Product;
import com.cognizant.helper.ConnectionManager;

public class JDBCProductDAOImpl implements ProductDAO{
	
	private ConnectionManager manager=new ConnectionManager();

	@Override
	public boolean addProduct(Product product) {
		// TODO Auto-generated method stub
		boolean result=false;
		Connection connection=manager.openConnection();
		try {
			PreparedStatement statement=connection.prepareStatement("insert into PRODUCTDATA(PRODUCT_ID,PRODUCT_NAME,PRODUCT_CAT,PRODUCT_PRICE,PRODUCT_BRAND) values(?,?,?,?,?)");
			statement.setInt(1,product.getProductID());
			statement.setString(2,product.getProductName());
			statement.setString(3,product.getProductCategory());
			statement.setInt(4,product.getProductPrice());
			statement.setString(5,product.getProductBrand() );
			int rows=statement.executeUpdate();
			if(rows>0)
				result=true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(result==true)
			return true;
		else
			return false;
		
	}

	@Override
	public boolean checkProduct(int productId) {
		// TODO Auto-generated method stub
		boolean result=false;
		Connection connection=manager.openConnection();
		try{
			PreparedStatement statement=connection.prepareStatement("Select * from PRODUCTDATA where PRODUCT_ID=?");
			statement.setInt(1,productId);
			ResultSet resultSet=statement.executeQuery();
			while(resultSet.next())
			{
				result=true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		manager.closeConnection();
		return result;
		
	}

	@Override
	public List<Product> viewProduct() {
		// TODO Auto-generated method stub
		Connection connection=manager.openConnection();
		List<Product> result=new ArrayList<>();
		
		try {
			PreparedStatement statement=connection.prepareStatement("select * from PRODUCTDATA");
			ResultSet resultSet=statement.executeQuery();
			while(resultSet.next())
			{
				Product product=new Product();
				product.setProductID(resultSet.getInt("PRODUCT_ID"));
				product.setProductName(resultSet.getString("PRODUCT_NAME"));
				product.setProductCategory(resultSet.getString("PRODUCT_CAT"));
				product.setProductBrand(resultSet.getString("PRODUCT_BRAND"));
				product.setProductPrice(resultSet.getInt("PRODUCT_PRICE"));
				product.setProductRating(resultSet.getInt("PRODUCT_RATING"));
				System.out.println("Data added to list!!!!");
				result.add(product);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Number of data entries :"+result.size());
		return result;
	}

	@Override
	public List<Product> sortRating() {
		// TODO Auto-generated method stub
		Connection connection=manager.openConnection();
		List<Product> result=new ArrayList<>();
		
		try {
			PreparedStatement statement=connection.prepareStatement("select * from PRODUCTDATA orderby PRODUCT_RATING ASC");
			ResultSet resultSet=statement.executeQuery();
			while(resultSet.next())
			{
				Product product=new Product();
				product.setProductID(resultSet.getInt("PRODUCT_ID"));
				product.setProductName(resultSet.getString("PRODUCT_NAME"));
				product.setProductCategory(resultSet.getString("PRODUCT_CAT"));
				product.setProductBrand(resultSet.getString("PRODUCT_BRAND"));
				product.setProductPrice(resultSet.getInt("PRODUCT_PRICE"));
				product.setProductRating(resultSet.getInt("PRODUCT_RATING"));
				System.out.println("Data added to list!!!!");
				result.add(product);
			}
		
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return result;
	}

	@Override
	public List<Product> sortPrice() {
		// TODO Auto-generated method stub
		Connection connection=manager.openConnection();
		List<Product> result=new ArrayList<>();
		try {
			PreparedStatement statement=connection.prepareStatement("select * from PRODUCTDATA orderby PRODUCT_PRICE ASC");
			ResultSet resultSet=statement.executeQuery();
			while(resultSet.next())
			{
				Product product=new Product();
				product.setProductID(resultSet.getInt("PRODUCT_ID"));
				product.setProductName(resultSet.getString("PRODUCT_NAME"));
				product.setProductCategory(resultSet.getString("PRODUCT_CAT"));
				product.setProductBrand(resultSet.getString("PRODUCT_BRAND"));
				product.setProductPrice(resultSet.getInt("PRODUCT_PRICE"));
				product.setProductRating(resultSet.getInt("PRODUCT_RATING"));
				System.out.println("Data added to list!!!!");
				result.add(product);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return result;
	}

	@Override
	public List<Product> sortName() {
		// TODO Auto-generated method stub
		Connection connection=manager.openConnection();
		List<Product> result=new ArrayList<>();
		try {
			PreparedStatement statement=connection.prepareStatement("select * from PRODUCTDATA orderby PRODUCT_NAME ASC");
			ResultSet resultSet=statement.executeQuery();
			while(resultSet.next())
			{
				Product product=new Product();
				product.setProductID(resultSet.getInt("PRODUCT_ID"));
				product.setProductName(resultSet.getString("PRODUCT_NAME"));
				product.setProductCategory(resultSet.getString("PRODUCT_CAT"));
				product.setProductBrand(resultSet.getString("PRODUCT_BRAND"));
				product.setProductPrice(resultSet.getInt("PRODUCT_PRICE"));
				product.setProductRating(resultSet.getInt("PRODUCT_RATING"));
				System.out.println("Data added to list!!!!");
				result.add(product);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return result;
	}
	   	
}
