package com.cognizant.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.dao.ProductDAO;
import com.cognizant.entity.Product;
import com.cognizant.helper.FactoryProductDAO;

/**
 * Servlet implementation class SortProductClass
 */
@WebServlet(name = "SortProduct", urlPatterns = { "/sortproduct" })
public class SortProductClass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SortProductClass() {
        super();
        // TODO Auto-generated constructor stub
    }



	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//String sortValue=request.getParameter("option");
		ProductDAO productDAO=FactoryProductDAO.createProductDAO();
		List<Product> productList=new ArrayList<>();
//		switch(sortValue)
//		{
//		case "sortRating":productList=productDAO.sortRating();
//		break;
//		case "sortPrice":productList=productDAO.sortPrice();
//		break;
//		case "sortName":productList=productDAO.sortName();
//		break;
//		}
		
		request.setAttribute("productList", productList);
		ServletContext sc = this.getServletContext();
		System.out.println("ViewProduct jsp called !!!!!!");
		RequestDispatcher rd = sc.getRequestDispatcher("/ViewProduct.jsp");
		rd.include(request, response);
	
		
	}



	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(req, resp);
		ProductDAO productDAO=FactoryProductDAO.createProductDAO();
		List<Product> productList=new ArrayList<>();
		productList=productDAO.sortRating();
		req.setAttribute("productList", productList);
		System.out.println("Sort servlet Called !!!!!!!!!!");
		ServletContext sc = this.getServletContext();
		System.out.println("ViewProduct jsp called !!!!!!");
		RequestDispatcher rd = sc.getRequestDispatcher("/ViewProduct.jsp");
		rd.forward(req, resp);
	}

}
