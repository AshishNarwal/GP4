package com.cognizant.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.dao.ProductDAO;
import com.cognizant.entity.Product;
import com.cognizant.helper.FactoryProductDAO;

/**
 * Servlet implementation class ViewProductClass
 */
@WebServlet(name = "ViewProduct", urlPatterns = { "/viewproduct" })
public class ViewProductClass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewProductClass() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		ProductDAO productDAO=FactoryProductDAO.createProductDAO();
		List<Product> productList=productDAO.viewProduct();
		request.setAttribute("productList", productList);
		ServletContext sc = this.getServletContext();
		System.out.println("ViewProduct jsp called !!!!!!");
		RequestDispatcher rd = sc.getRequestDispatcher("/ViewProduct.jsp");
		rd.include(request, response);
	}

}
