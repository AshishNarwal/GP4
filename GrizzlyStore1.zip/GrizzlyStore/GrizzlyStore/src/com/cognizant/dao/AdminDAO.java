package com.cognizant.dao;

public interface AdminDAO {
	
	

	public boolean authAdmin(String username, String password);

}
