package com.cognizant.helper;

import com.cognizant.dao.AdminDAO;


import com.cognizant.dao.JDBCAdminDAOImpl;


public class FactoryAdminDAO {
	

	public static AdminDAO createAdminDAO() {
		// TODO Auto-generated method stub
		AdminDAO adminDAO=new JDBCAdminDAOImpl();
		return adminDAO;
	}


}
